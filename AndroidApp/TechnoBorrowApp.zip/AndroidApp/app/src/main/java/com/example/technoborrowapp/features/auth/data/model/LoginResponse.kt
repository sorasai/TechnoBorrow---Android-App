package com.example.technoborrowapp.features.auth.data.model

data class LoginResponse(
    val message: String,
    val user: User
)

data class User(
    val id: Int,
    val email: String,
    val fullName: String
)
