package com.example.technoborrowapp.core.network

import com.example.technoborrowapp.features.auth.data.model.LoginRequest
import com.example.technoborrowapp.features.auth.data.model.LoginResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {

    @POST("auth/login")
    fun login(
        @Body request: LoginRequest
    ): Call<String>

}
